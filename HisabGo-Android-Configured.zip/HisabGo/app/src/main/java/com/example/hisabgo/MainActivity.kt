package com.example.hisabgo

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val INCOME = "INCOME"
private const val EXPENSE = "EXPENSE"

data class LedgerEntry(
    val id: Long,
    val type: String,
    val amount: Long,
    val description: String,
    val createdAt: Long
)

data class ParsedSpeech(val type: String?, val amount: Long?, val description: String)

class LedgerDb(context: Context) : SQLiteOpenHelper(context, "hisabgo.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, amount INTEGER NOT NULL, description TEXT NOT NULL, created_at INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun add(type: String, amount: Long, description: String) {
        val values = ContentValues().apply {
            put("type", type)
            put("amount", amount)
            put("description", description.ifBlank { if (type == INCOME) "درآمد / فروش" else "هزینه / خرید" })
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insertOrThrow("entries", null, values)
    }

    fun all(): List<LedgerEntry> {
        val result = mutableListOf<LedgerEntry>()
        readableDatabase.rawQuery(
            "SELECT id, type, amount, description, created_at FROM entries ORDER BY created_at DESC, id DESC", null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += LedgerEntry(
                    id = cursor.getLong(0),
                    type = cursor.getString(1),
                    amount = cursor.getLong(2),
                    description = cursor.getString(3),
                    createdAt = cursor.getLong(4)
                )
            }
        }
        return result
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var ledgerDb: LedgerDb
    private var recognizedText by mutableStateOf("")
    private var recognitionVersion by mutableIntStateOf(0)

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                recognizedText = text
                recognitionVersion++
            } else {
                Toast.makeText(this, "صدایی تشخیص داده نشد؛ دوباره تلاش کنید.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognition()
        else Toast.makeText(this, "برای ورود صوتی، اجازهٔ میکروفون لازم است.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ledgerDb = LedgerDb(this)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    LedgerScreen(
                        db = ledgerDb,
                        recognitionVersion = recognitionVersion,
                        recognizedText = recognizedText,
                        onVoiceClick = { requestVoiceInput() }
                    )
                }
            }
        }
    }

    private fun requestVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchSpeechRecognition()
        } else {
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun launchSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "مثلاً بگویید: فروش دو میلیون تومان")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "سرویس تشخیص گفتار روی این گوشی در دسترس نیست.", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
private fun LedgerScreen(
    db: LedgerDb,
    recognitionVersion: Int,
    recognizedText: String,
    onVoiceClick: () -> Unit
) {
    var entries by remember { mutableStateOf(db.all()) }
    var selectedType by remember { mutableStateOf(INCOME) }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var latestVoice by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    LaunchedEffect(recognitionVersion) {
        if (recognitionVersion > 0 && recognizedText.isNotBlank()) {
            latestVoice = recognizedText
            val parsed = parsePersianSpeech(recognizedText)
            parsed.type?.let { selectedType = it }
            parsed.amount?.takeIf { it > 0 }?.let { amountText = it.toString() }
            description = recognizedText
            errorMessage = if (parsed.amount == null) "مبلغ پیدا نشد؛ مبلغ را بررسی و وارد کنید." else ""
        }
    }

    val incomeTotal = entries.filter { it.type == INCOME }.sumOf { it.amount }
    val expenseTotal = entries.filter { it.type == EXPENSE }.sumOf { it.amount }
    val balance = incomeTotal - expenseTotal

    androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("حساب‌گو", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("حسابداری صوتی مغازه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(onClick = onVoiceClick, shape = RoundedCornerShape(14.dp)) {
                    Text("🎙 ثبت با صدا")
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مانده حساب", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("${formatMoney(balance)} تومان", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        SummaryMini("درآمد", incomeTotal, Modifier.weight(1f))
                        SummaryMini("هزینه", expenseTotal, Modifier.weight(1f))
                    }
                }
            }

            Text("ثبت تراکنش", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedType == INCOME) {
                    Button(onClick = { selectedType = INCOME }, modifier = Modifier.weight(1f)) { Text("درآمد / فروش") }
                } else {
                    OutlinedButton(onClick = { selectedType = INCOME }, modifier = Modifier.weight(1f)) { Text("درآمد / فروش") }
                }
                if (selectedType == EXPENSE) {
                    Button(onClick = { selectedType = EXPENSE }, modifier = Modifier.weight(1f)) { Text("هزینه / خرید") }
                } else {
                    OutlinedButton(onClick = { selectedType = EXPENSE }, modifier = Modifier.weight(1f)) { Text("هزینه / خرید") }
                }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = normalizeDigits(it).filter { ch -> ch.isDigit() } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("مبلغ به تومان") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("شرح تراکنش (قابل ویرایش)") },
                singleLine = false,
                maxLines = 2
            )
            if (latestVoice.isNotBlank()) {
                Text("متن شنیده‌شده: $latestVoice", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (errorMessage.isNotBlank()) {
                Text(errorMessage, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }
            Button(
                onClick = {
                    val amount = amountText.toLongOrNull()
                    if (amount == null || amount <= 0L) {
                        errorMessage = "لطفاً یک مبلغ معتبر و بزرگ‌تر از صفر وارد کنید."
                    } else {
                        db.add(selectedType, amount, description.trim())
                        entries = db.all()
                        amountText = ""
                        description = ""
                        latestVoice = ""
                        errorMessage = "تراکنش ذخیره شد."
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("ذخیره تراکنش", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("تراکنش‌های اخیر", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { entries = db.all() }) { Text("به‌روزرسانی") }
            }
            if (entries.isEmpty()) {
                Text("هنوز تراکنشی ثبت نشده است. برای شروع، روی «ثبت با صدا» بزنید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(entries, key = { it.id }) { entry ->
                        EntryCard(entry)
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryMini(label: String, amount: Long, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(top = 4.dp)) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Text("${formatMoney(amount)} تومان", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
private fun EntryCard(entry: LedgerEntry) {
    val isIncome = entry.type == INCOME
    val dateText = remember(entry.createdAt) {
        SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa", "IR")).format(Date(entry.createdAt))
    }
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(entry.description.ifBlank { if (isIncome) "درآمد / فروش" else "هزینه / خرید" }, fontWeight = FontWeight.SemiBold)
                Text(dateText, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                (if (isIncome) "+ " else "− ") + formatMoney(entry.amount),
                fontWeight = FontWeight.Bold,
                color = if (isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}

private fun formatMoney(amount: Long): String = NumberFormat.getIntegerInstance(Locale("fa", "IR")).format(amount)

private fun normalizeDigits(input: String): String {
    val persian = "۰۱۲۳۴۵۶۷۸۹"
    val arabic = "٠١٢٣٤٥٦٧٨٩"
    return buildString {
        input.forEach { ch ->
            when {
                ch in persian -> append(('0'.code + persian.indexOf(ch)).toChar())
                ch in arabic -> append(('0'.code + arabic.indexOf(ch)).toChar())
                ch == '٬' || ch == ',' -> append(',')
                else -> append(ch)
            }
        }
    }
}

private fun parsePersianSpeech(raw: String): ParsedSpeech {
    val text = normalizeDigits(raw).lowercase(Locale.ROOT)
    val type = when {
        listOf("هزینه", "خرید", "پرداخت", "خرج", "برداشت", "خریدم", "پرداختم").any { text.contains(it) } -> EXPENSE
        listOf("فروش", "درآمد", "دریافت", "واریز", "فروختم", "گرفتم").any { text.contains(it) } -> INCOME
        else -> null
    }
    val amount = parseAmount(text)
    return ParsedSpeech(type, amount, raw.trim())
}

private fun parseAmount(text: String): Long? {
    // Exact digit amounts (e.g. 250000 or 2,500,000) take priority.
    val grouped = Regex("(?<![\\d])\\d{1,3}(?:,\\d{3})+(?![\\d])").findAll(text)
        .mapNotNull { it.value.replace(",", "").toLongOrNull() }.maxOrNull()
    if (grouped != null) return grouped
    val longDigits = Regex("\\d{4,}").findAll(text).mapNotNull { it.value.toLongOrNull() }.maxOrNull()
    if (longDigits != null) return longDigits

    val ones = mapOf(
        "صفر" to 0L, "یک" to 1L, "یه" to 1L, "یکی" to 1L, "دو" to 2L, "سه" to 3L,
        "چهار" to 4L, "پنج" to 5L, "شش" to 6L, "هفت" to 7L, "هشت" to 8L, "نه" to 9L,
        "ده" to 10L, "یازده" to 11L, "دوازده" to 12L, "سیزده" to 13L, "چهارده" to 14L,
        "پانزده" to 15L, "شانزده" to 16L, "هفده" to 17L, "هجده" to 18L, "نوزده" to 19L,
        "بیست" to 20L, "سی" to 30L, "چهل" to 40L, "پنجاه" to 50L, "شصت" to 60L,
        "هفتاد" to 70L, "هشتاد" to 80L, "نود" to 90L,
        "صد" to 100L, "یکصد" to 100L, "دویست" to 200L, "سیصد" to 300L,
        "چهارصد" to 400L, "پانصد" to 500L, "ششصد" to 600L, "هفتصد" to 700L,
        "هشتصد" to 800L, "نهصد" to 900L
    )
    val multipliers = mapOf("هزار" to 1_000L, "میلیون" to 1_000_000L, "میلیارد" to 1_000_000_000L)
    val tokens = text.replace("تومان", " ").replace("تومن", " ").replace("ریال", " ")
        .replace("امروز", " ").replace("دیروز", " ").replace("،", " ").split(Regex("\\s+"))
    var current = 0L
    var total = 0L
    var sawNumber = false
    for (token in tokens) {
        if (token.isBlank() || token == "و") continue
        val numeric = token.replace(",", "").toLongOrNull()
        when {
            numeric != null && numeric < 1_000L -> { current += numeric; sawNumber = true }
            token in ones -> { current += ones.getValue(token); sawNumber = true }
            token in multipliers -> {
                val multiplier = multipliers.getValue(token)
                total += (if (current == 0L) 1L else current) * multiplier
                current = 0L
                sawNumber = true
            }
        }
    }
    val result = total + current
    return if (sawNumber && result > 0) result else null
}
