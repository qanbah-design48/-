# Building HisabGo APK

## Build a debug APK with Android Studio

1. Install Android Studio and Android SDK Platform 35.
2. Open the `HisabGo` project directory.
3. Allow Gradle sync to finish. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and Gradle 8.9.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build from a terminal

Use JDK 17 and Android SDK Platform 35, then run from this directory:

```bash
gradle --no-daemon :app:assembleDebug
```

## Build automatically with GitHub Actions

Push this project to a GitHub repository on the `main` or `master` branch, or run the **Build Android APK** workflow manually from the Actions tab. Download the `HisabGo-debug-apk` artifact from the completed workflow run.

## App configuration

- Application ID: `com.example.hisabgo`
- Version: `0.1.0` (version code `1`)
- Minimum Android version: Android 8.0 (API 26)
- Target / compile SDK: Android 15 (API 35)
- APK type: debug-signed, suitable for installation/testing, not Play Store release

A release APK requires a private signing keystore. Do not commit keystore files or passwords to source control. Configure release signing with your own protected credentials before distribution.
